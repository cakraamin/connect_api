<?php
umask(0);

mysql_connect("10.116.224.14","livaza","hidupmakmur");
mysql_select_db("livaacom-livedb");
$sql_selek = "SELECT * FROM cakra_category ORDER BY tanggal ASC";
$kueri = mysql_query($sql_selek);

while($data = mysql_fetch_array($kueri)){
    echo $data['0']." dan ".$data['1']." dan ".$data['2']."<br/>";
}

$sql_export = "SELECT * FROM export";
$kueri_e = mysql_query($sql_export);

while($datae = mysql_fetch_array($kueri_e)){
    echo $datae['0']." dan ".$datae['1']." dan ".$datae['2']."<br/>";
}
?>